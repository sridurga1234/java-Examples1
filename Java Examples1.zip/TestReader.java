package com.Exception;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class TestReader {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		try{
			FileReader fReader = new FileReader("D:textfile.txt");
			int c;
			while((c=fReader.read())!=-1)
			{
				System.out.println(c);
			}
				
		fReader.close();
		
		}
		catch(FileNotFoundException e){
			e.printStackTrace();
		}
}
}