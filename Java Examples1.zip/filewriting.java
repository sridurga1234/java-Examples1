package com.Exception;

import java.io.FileWriter;
import java.io.IOException;

public class filewriting {
public static void main(String args[])
{
	try{
		FileWriter writer=new FileWriter("D:textfile.txt",true);
		writer.write("hello");
		writer.write("\r\n");
		writer.write("good bye");
		writer.close();
	}catch(IOException e)
	{
		e.printStackTrace();
	}
}
}
