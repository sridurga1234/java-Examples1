package com.Exception;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Scanner;

public class Age1
{
	public static void main(String[] args)  {
		Scanner b = new Scanner(System.in);
		System.out.println();
		int a = b.nextInt();
		if(a<18)
			throw new AgeClass("Invalid User");
	
	System.out.println("invalid");

	}
}