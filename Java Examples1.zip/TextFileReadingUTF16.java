package com.Exception;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

public class TextFileReadingUTF16 {
	public static void main(String args[])
	{
		try{
			FileInputStream inputStream =  new FileInputStream("D:textfile.txt");
			InputStreamReader reader = new InputStreamReader(inputStream,"UTF-8");
			int Character;
			while((Character=reader.read())!=-1)
			{
				System.out.println((char)Character);
				
			}
		reader.close();
	}
		catch(IOException e)
		{
			e.printStackTrace();
		}
}
}
