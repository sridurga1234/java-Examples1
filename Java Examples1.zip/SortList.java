package com.Exception;

import java.util.ArrayList;
import java.util.Collections;

public class SortList {
public static void main(String args[])
{
	ArrayList<String> s1 = new ArrayList<>();
	s1.add("ravi");
	s1.add("ramu");
	s1.add("kavin");
	s1.add("sri");
	Collections.sort(s1);
	System.out.println(s1);
}
}
