package com.Exception;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;

public class BufferedWriterDemo {

	public static void main(String[] args) throws IOException {
		try{
			FileWriter fileWriter = new FileWriter("D:textfile.txt",true);
			BufferedWriter b = new BufferedWriter(fileWriter);
			b.write("sri");
			b.newLine();
			b.write("durga");
			b.close();
		}catch(FileNotFoundException e)
		{
			e.printStackTrace();
		}

	}

}
