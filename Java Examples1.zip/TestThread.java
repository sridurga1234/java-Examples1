package com.Exception;

public class TestThread implements Runnable{

	@Override
	public void run() {
		// TODO Auto-generated method stub
			System.out.println("threadddd");
		
	}
	public static void main(String args[]) throws InterruptedException
	{
		TestThread testThread =  new TestThread();
		Thread t = new Thread(testThread);
		t.setName("User thread");
		t.start();
	}
	

}
