package com.Exception;

import java.awt.List;
import java.util.ArrayList;
import java.util.Iterator;

public class ArrayListExample {
	public static void main(String args[]){
	ArrayList<String> li  = new ArrayList<String>();
	li.add("amul");
	li.add("rohan");
	li.add("rita");
	System.out.println(li);
	ArrayList li2 = new ArrayList();
	li2.add(10);
	li2.add(1,15);
	 li2.addAll(li);
	 li2.add(1,null);
	 li2.add(3,null);  
	System.out.println(li2);
	if(li2.contains("amul")){
		System.out.println("value exists");
	}
	else
	{
		System.out.println("value doesnot exists");
	}
	Iterator iterator = li.iterator();
	while(iterator.hasNext())
	{
		System.out.println(iterator.next());
	}
	}
	
	}
	
	

