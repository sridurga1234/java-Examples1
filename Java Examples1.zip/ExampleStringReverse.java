package com.Exception;

import java.util.Stack;

public class ExampleStringReverse {		  
		
		static void reverseString(String str) 
		{ 
		    Stack<Character> st=new Stack<Character>(); 
		    for (int i = 0; i < str.length(); ++i) { 
		    	 
		        if (str.charAt(i) != 0 ) 
		        {
		        	
		            st.push(str.charAt(i)); 
		            System.out.print("-");
		            st.push(str.charAt(i)); 
		        
		        }
		        else { 
		            while (st.empty() == false) { 
		                System.out.print(st.pop()); 
		                  
		            } 
		           
		        } 
		    } 
		    System.out.print("-"); 
		    while (st.empty() == false) { 
		        System.out.print(st.pop()); 
		          
		    }
		    System.out.print("-");
		} 
		  
		// Driver program to test above function 
		public static void main(String[] args) 
		{ 
		   String str = "Rabbit";
		    reverseString(str);
		  } 
		} 

