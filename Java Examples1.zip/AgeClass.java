package com.Exception;

public class AgeClass extends RuntimeException{
	String message;

	public AgeClass(String message) {
		super();
		this.message = message;
	}
	public String getMessage() {
		return message;
	}
	

}
