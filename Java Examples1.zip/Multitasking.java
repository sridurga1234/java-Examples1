package com.Exception;

public class Multitasking extends Thread {
	
	public void run() 
	{
		System.out.println("thread1");
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			
			e.printStackTrace();
		}
		System.out.println("thread1 completed");
	}
	
}
class Tasking extends Thread
{
	public void run()
	{
		System.out.println("thread 2");
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("thread 2 completed");
	}
	public static void main(String args[])
	{
		Tasking tasking = new Tasking();
		tasking.start();
		Multitasking multitasking = new Multitasking();
		multitasking.start();
	}
}

