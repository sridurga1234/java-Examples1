package com.Exception;

import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;

public class TreeMapDemo {

	 public static void main(String args[]){  
	   TreeMap<Integer,String> hm=new TreeMap<Integer,String>();     
	      hm.put(100,"A");    
	      hm.put(102,"B");    
	      hm.put(101,"C");   
	       
	      System.out.println("After invoking put() method ");  
	      for(Map.Entry m:hm.entrySet()){    
	       System.out.println(m.getKey()+" "+m.getValue());    
	      }  
	        
	      hm.putIfAbsent(103, "D");  
	      System.out.println("After invoking putIfAbsent() method ");  
	      for(Map.Entry m:hm.entrySet()){    
	           System.out.println(m.getKey()+" "+m.getValue());    
	          }  
	      System.out.println("While Loop");
	      Iterator iterator = hm.entrySet().iterator();
	      while(iterator.hasNext()){
	    	  Map.Entry mEntry = (Map.Entry) iterator.next();
	    	  System.out.println("key : "+mEntry.getKey()+"& value:"+mEntry.getValue()+"& name");
	      }
	     
	 }  
	}  



