package com.Exception;

public class Sttudent {

	public int age;
	public int name;
	public String rollno;

	public Sttudent(int i, String string, int j) {
		// TODO Auto-generated constructor stub
	}

	public void Sttudent1(int i, String string, int j) {
		// TODO Auto-generated constructor stub
	}

}
