package com.Exception;
public class Laptop{
private static final long serialVersionUID = 1L;
private String company;
private int HD;
private int processsor;
public Laptop(String company, int HD, int processsor) {
super();
this.company = company;
this.HD = HD;
this.processsor = processsor;
}
@Override
public String toString() {
return "Laptop [company=" + company + ", HD=" + HD + ", processsor=" + processsor + "]";
}
}
