package com.Exception;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class BufferedDemo {

	public static void main(String[] args) throws IOException{
		// TODO Auto-generated method stub
		try{
				FileReader inputStream =  new FileReader("D:textfile.txt");
				BufferedReader reader = new BufferedReader(inputStream);
				int Character;
				while((Character=reader.read())!=-1)
				{
					System.out.println((char)Character);
					
				}
			reader.close();
		}
			catch(FileNotFoundException e)
			{
				e.printStackTrace();
			}
	}
	}


