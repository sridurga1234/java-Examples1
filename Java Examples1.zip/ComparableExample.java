package com.Exception;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ComparableExample{  
public static void main(String args[]) throws IOException{  
ArrayList<Sttudent> al=new ArrayList<Sttudent>();  
al.add(new Sttudent(101,"Vijay",23));  
al.add(new Sttudent(106,"Ajay",27));  
al.add(new Sttudent(105,"Jai",21));  
  
Collections.sort((List<T>) al);  
for(Sttudent st:al){  
System.out.println(st.rollno+" "+st.name+" "+st.age);  
}  
}  
}  